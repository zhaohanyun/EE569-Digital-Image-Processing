All the problem this time requires Opencv so just run then in CLion with proper setting in Cmakelist activated. 

And also, for the 3D plot, Kmeans, RF, SVM, they requires certain module so collboration of Python is needed. I either use standard output then copy paste, or output to file, to convey information between C++ and python programs.

For Problem3, SIFT algorithm does not work on C++ and Matlab, so no effective code.