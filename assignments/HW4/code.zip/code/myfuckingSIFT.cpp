#include <iostream>
#include <vector>
#include "fileIO.h"
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/xfeatures2d/nonfree.hpp>

int main(){
    cout<<"hello"<<endl;
    return 0;
}