clear all;
clc;
close all;

mbvq='CMGB';
R=233.0;
G=233.0;
B=233.0;

vertex=getNearestVertex(mbvq, R, G, B);
